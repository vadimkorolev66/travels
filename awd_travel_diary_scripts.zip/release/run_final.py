#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, '/home/claude/work')
from awd_convert import convert
from cross_reference_fixes import CROSS_REFERENCE_FIXES

# Bretagne's raw-URL hiding fixes from the earlier session (kept file-specific).
BRETAGNE_LINK_FIXES = [
    (r'воспользоваться планировщиком \[url\](http://www\.breizhgo\.com/fr/)\[/url\]',
     r'воспользоваться [url=\1]планировщиком[/url]'),
    (r'Сайт SNCF \[url\](https://www\.voyages-sncf\.com/)\[/url\]\.',
     r'Билеты покупал [url=\1]здесь[/url].'),
    (r'Снова сайт SNCF \[url\](https://www\.voyages-sncf\.com/)\[/url\]\.',
     r'Билеты снова покупал [url=\1]здесь[/url].'),
    (r'\[url\](http://www\.compagnie-du-golfe\.fr/bateau-belle-ile-en-mer/depart-vannes-et-port-navalo/#horaires-belle-ile)\[/url\]',
     'Билеты покупал [url=\\1]здесь[/url].\x00MERGE_NEXT\x00'),
    (r'\[url\](http://www\.compagnie-oceane\.fr/reservation/\?rub_code=53)\[/url\]',
     'Билеты покупал [url=\\1]здесь[/url].\x00MERGE_NEXT\x00'),
    (r'\[url\](http://www\.pennarbed\.fr/horaires-et-tarifs/)\[/url\]',
     r'Билеты покупал [url=\1]здесь[/url].'),
    (r'их собственным «островным» сервисом по подбору крыши над головой:',
     r'их [url=http://www.ot-ouessant.fr/location-ouessant.html]собственным «островным» сервисом[/url] по подбору крыши над головой.'),
    (r'^\[url\]http://www\.ot-ouessant\.fr/location-ouessant\.html\[/url\]$',
     '\x00DELETE\x00'),
    (r'В результате, только маленькая гостиница Le Fromveur в центре',
     r'В результате, только [url=http://www.ot-ouessant.fr/location-ouessant/hotel/173-hotel-restaurant-bar-le-fromveur.html]маленькая гостиница Le Fromveur[/url] в центре'),
    (r'Lampole - он же столица Уэссана - оказалась подходящей:',
     r'Lampole - он же столица Уэссана - оказалась подходящей.'),
    (r'^\[url\]http://www\.ot-ouessant\.fr/location-ouessant/hotel/173-hotel-restaurant-bar-le-fromveur\.html\[/url\]$',
     '\x00DELETE\x00'),
    (r'\[url\](http://www\.belle-ile\.com/files/ot-belleile/files/fichiers/Organiser/SeDeplacer/belle_ile_bus\.jpg)\[/url\]',
     r'[url=\1]Ссылка[/url]'),
    (r'вот их собственный сайт: \[url\](http://www\.hotel-fromveur\.fr/)\[/url\]',
     r'вот их [url=\1]собственный сайт[/url]'),
    (r'Спойлер – да, можно: \[url\](http://www\.garemontparnasse\.paris/consignes-automatiques-bagages\.php)\[/url\]',
     r'Спойлер – [url=\1]да, можно[/url]'),
    (r'Обнаружил забавный сервис \[url\](http://www\.gares360\.com/)\[/url\]',
     r'Обнаружил [url=\1]забавный сервис[/url]'),
    (r'Вот ссылка для вокзала Монпарнас: \[url\](http://devaccess\.itiview\.com/itiview/index\.php\?project=140)\[/url\]',
     r'Вот [url=\1]ссылка для вокзала Монпарнас[/url]'),
    (r'Здесь вот можно найти обычный «олдскульный» план всех этажей, если что: '
     r'\[url\](https://www\.gares-sncf\.com/sites/default/files/field_plan_files/2016-01/pmp_n-01\.pdf)\[/url\]',
     r'[url=\1]Здесь[/url] вот можно найти обычный «олдскульный» план всех этажей, если что'),
    (r'\(\[url\](https://www\.google\.fr/maps/@48\.8395311,2\.3365645,3a,75y,280\.54h,96\.87t/data=![^\]]*)\[/url\]\)',
     r'([url=\1]здесь на карте[/url])'),
    (r'у \[b\]\[i\]luchar\[/i\]\[/b\] \(\[url\](http://forum\.awd\.ru/viewtopic\.php\?t=210464)\[/url\]\)',
     r'[url=\1]у luchar[/url]'),
    (r'Разжиться расписанием можно здесь: '
     r'\[url\](http://www\.belle-ile\.com/organiser/se-deplacer-sur-lile/en-bus)\[/url\]',
     r'Разжиться расписанием можно [url=\1]здесь[/url]'),
    (r'весеннее расписание висит тут: '
     r'\[url\](http://www\.belle-ile\.com/files/ot-belleile/files/fichiers/Organiser/SeDeplacer/belle_ile_bus_printemps_automne2017\.pdf)\[/url\]',
     r'весеннее расписание висит [url=\1]тут[/url]'),
    (r'«Мир искусства»\) \(\[url\](http://www\.kultpro\.ru/item_688/)\[/url\]\)\. Процитирую:',
     r'«Мир искусства»). [url=\1]Процитирую[/url]:'),
]

# Same photo used for this report's card on the landing page (index.html),
# reused here as the faded header-banner photo on the report page itself.
REPORT_PHOTOS = {
    '2012_benelux': 'https://live.staticflickr.com/65535/49901218392_a0d54efc3f_o.jpg',
    '2014_east_brittany': 'https://live.staticflickr.com/65535/49821015786_58b1e7bbee_o.jpg',
    '2014_salzburg': 'https://live.staticflickr.com/65535/54107976442_95d7722974_b.jpg',
    '2015_georgia': 'https://img-fotki.yandex.ru/get/477594/2188450.14/0_1e64eb_b3300372_orig',
    '2015_bavaria_salzkammergut': 'https://live.staticflickr.com/65535/54425096785_db01c8f1da_o.jpg',
    '2016_andalusia': 'https://img-fotki.yandex.ru/get/369579/2188450.1f/0_1e895c_55b263ef_orig',
    '2016_alsace': 'https://img-fotki.yandex.ru/get/478621/2188450.1c/0_1e8001_4aa8881e_orig',
    '2017_bretagne': 'https://img-fotki.yandex.ru/get/202427/2188450.1/0_1df61f_1660e0d1_orig',
    '2017_alps': 'https://img-fotki.yandex.ru/get/478662/2188450.8/0_1e24a3_5de382fd_orig',
    '2018_north_italy': 'https://farm1.staticflickr.com/958/41335390605_5b8c55d78a_b.jpg',
    '2018_switzerland': 'https://farm5.staticflickr.com/4912/45696010801_9791bb5db6_o.jpg',
    '2019_normandy': 'https://live.staticflickr.com/65535/48214170891_b5529f5d72_o.jpg',
    '2019_dolomites_garda': 'https://live.staticflickr.com/65535/49002758212_92d4418297_o.jpg',
    '2021_three_routes_1': 'https://live.staticflickr.com/65535/51892272407_cb677a6695_o.jpg',
    '2021_three_routes_2': 'https://live.staticflickr.com/65535/51740529969_7f36a1e7f4_o.jpg',
    '2021_three_routes_3': 'https://live.staticflickr.com/65535/51893568129_19725c3e6c_o.jpg',
    '2021_istanbul_nov': 'https://live.staticflickr.com/65535/51708667204_6e57a42a07_o.jpg',
    '2022_istanbul_oct': 'https://live.staticflickr.com/65535/52482440583_c003da0526_o.jpg',
    '2023_armenia1': 'https://live.staticflickr.com/65535/53065578884_082c55db69_o.jpg',
    '2023_elbrus': 'https://live.staticflickr.com/65535/53461347506_0ea082387a_o.jpg',
    '2024_armenia2': 'https://live.staticflickr.com/65535/53726915126_c6bc16b367_o.jpg',
    '2024_venice_dolomites': 'https://live.staticflickr.com/65535/54027023736_20b39efefe_o.jpg',
    '2025_rome': 'https://live.staticflickr.com/65535/54300792337_712cb31068_o.jpg',
}

# Vertical crop position overrides (default is 40%, see awd_convert.py).
# Lower % = show more of the top of the photo; higher % = more of the bottom.
REPORT_PHOTO_POS = {
    '2014_east_brittany': '10%',
    '2015_bavaria_salzkammergut': '70%',
    '2018_switzerland': '20%',
    '2022_istanbul_oct': '55%',
    '2025_rome': '33%',
}

JOBS = [
    ('alsace', '_stage/alsace.html', 'Эльзас — глоток холодного рислинга в тени виноградной лозы', '2016_alsace'),
    ('bretagne', '_stage/bretagne.html', 'Западная Бретань — от Бель-Иля до Уэссана', '2017_bretagne'),
    ('alps', '_stage/alps.html', 'Альпы в августе — от озера к озеру, от Австрии к Баварии', '2017_alps'),
    ('salzburg', '_stage2/salzburg.html', 'Зальцбург под снегом. Воспоминание о новогодней Австрии', '2014_salzburg'),
    ('venice_dolomites', '_stage2/venice_dolomites.html', 'Венеция и Доломитовые Альпы. Горячее дыхание августа', '2024_venice_dolomites'),
    ('armenia2', '_stage2/armenia2.html', 'Возвращение в Армению. Год спустя', '2024_armenia2'),
    ('elbrus', '_stage2/elbrus.html', 'Неделя в Приэльбрусье', '2023_elbrus'),
    ('armenia1', '_stage2/armenia1.html', 'Армения. Знакомство длиной в тысячу километров', '2023_armenia1'),
    ('istanbul_oct', '_stage2/istanbul_oct.html', 'Октябрь в Стамбуле', '2022_istanbul_oct'),
    ('three_routes_1', '_stage2/three_routes_1.html', 'Три коротких маршрута нашего летнего отпуска. Часть первая: Суздаль и Владимир', '2021_three_routes_1'),
    ('three_routes_3', '_stage2/three_routes_3.html', 'Три коротких маршрута нашего летнего отпуска. Часть третья: Таруса', '2021_three_routes_3'),
    ('switzerland', '_stage2/switzerland.html', 'Швейцария. Прогулка рядом с облаками', '2018_switzerland'),
    ('andalusia', '_stage2/andalusia.html', 'Цвета Андалусии — белые города, песчаные дворцы, алое фламенко', '2016_andalusia'),
    ('normandy', '_stage2/normandy.html', 'Нормандия — безупречная линия горизонта', '2019_normandy'),
    ('dolomites_garda', '_stage2/dolomites_garda.html', 'Доломиты и озеро Гарда. Две недели в августе. Для пеших любителей горных пейзажей', '2019_dolomites_garda'),
    ('north_italy', '_stage2/north_italy.html', 'Города Северной Италии, или Мост над бездной', '2018_north_italy'),
    ('east_brittany', '_stage2/east_brittany.html', 'Восточная Бретань — от Арзона до Сен-Мало', '2014_east_brittany'),
    ('istanbul_nov', '_stage2/istanbul_nov.html', 'Стамбул. Три солнечных ноябрьских дня', '2021_istanbul_nov'),
    ('three_routes_2', '_stage2/three_routes_2.html', 'Три коротких маршрута нашего летнего отпуска. Часть вторая: Коломна и Константиново', '2021_three_routes_2'),
    ('benelux', '_stage2/benelux.html', 'Ностальгический рассказ о том, как не залечь на дно, путешествуя своим ходом по Бельгии и Нидерландам', '2012_benelux'),
    ('georgia', '_stage2/georgia.html', 'Грузия — по волнам моей фотопамяти', '2015_georgia'),
    ('bavaria_salzkammergut', '_stage3/bavaria.html', 'Бавария и Зальцкаммергут. Десять лет тому назад', '2015_bavaria_salzkammergut'),
    ('rome', '_stage3/rome.html', 'Рим. Пять дней в январе', '2025_rome'),
]

OUTDIR = '/mnt/user-data/outputs'
os.makedirs(OUTDIR, exist_ok=True)

for key, src, title, out_key in JOBS:
    fixes = list(CROSS_REFERENCE_FIXES.get(key, []))
    if key == 'bretagne':
        fixes = BRETAGNE_LINK_FIXES + fixes
    out_path = os.path.join(OUTDIR, f'{out_key}.html')
    r = convert(src, title, out_path, extra_fixes=fixes or None,
                header_photo=REPORT_PHOTOS.get(out_key),
                header_photo_pos=REPORT_PHOTO_POS.get(out_key, '40%'))
    flag = '⚠️' if r['leftover_tags'] else 'ok'
    print(f"{out_key:28s} headers={len(r['headers']):3d} leftover={r['leftover_tags']} {flag}")
