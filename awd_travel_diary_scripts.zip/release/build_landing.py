#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import html, os

REPORTS = [
    # file (no .html), title, year, month_label, photo_url
    ('2012_benelux', 'Ностальгический рассказ о том, как не залечь на дно, путешествуя своим ходом по Бельгии и Нидерландам',
     2012, 'август', 'https://live.staticflickr.com/65535/49901218392_a0d54efc3f_o.jpg'),
    ('2014_east_brittany', 'Восточная Бретань — от Арзона до Сен-Мало',
     2014, 'апрель', 'https://live.staticflickr.com/65535/49821015786_58b1e7bbee_o.jpg'),
    ('2014_salzburg', 'Зальцбург под снегом. Воспоминание о новогодней Австрии',
     2014, 'декабрь – январь', 'https://live.staticflickr.com/65535/54107976442_95d7722974_b.jpg'),
    ('2015_georgia', 'Грузия — по волнам моей фотопамяти',
     2015, 'апрель', 'https://img-fotki.yandex.ru/get/477594/2188450.14/0_1e64eb_b3300372_orig'),
    ('2015_bavaria_salzkammergut', 'Бавария и Зальцкаммергут. Десять лет тому назад',
     2015, 'август', 'https://live.staticflickr.com/65535/54425096785_db01c8f1da_o.jpg'),
    ('2016_andalusia', 'Цвета Андалусии — белые города, песчаные дворцы, алое фламенко',
     2016, 'апрель', 'https://img-fotki.yandex.ru/get/369579/2188450.1f/0_1e895c_55b263ef_orig'),
    ('2016_alsace', 'Эльзас — глоток холодного рислинга в тени виноградной лозы',
     2016, 'август', 'https://img-fotki.yandex.ru/get/478621/2188450.1c/0_1e8001_4aa8881e_orig'),
    ('2017_bretagne', 'Западная Бретань — от Бель-Иля до Уэссана',
     2017, 'апрель', 'https://img-fotki.yandex.ru/get/202427/2188450.1/0_1df61f_1660e0d1_orig'),
    ('2017_alps', 'Альпы в августе — от озера к озеру, от Австрии к Баварии',
     2017, 'август', 'https://img-fotki.yandex.ru/get/478662/2188450.8/0_1e24a3_5de382fd_orig'),
    ('2018_north_italy', 'Города Северной Италии, или Мост над бездной',
     2018, 'апрель', 'https://farm1.staticflickr.com/958/41335390605_5b8c55d78a_b.jpg'),
    ('2018_switzerland', 'Швейцария. Прогулка рядом с облаками',
     2018, 'август', 'https://farm5.staticflickr.com/4912/45696010801_9791bb5db6_o.jpg'),
    ('2019_normandy', 'Нормандия — безупречная линия горизонта',
     2019, 'май', 'https://live.staticflickr.com/65535/48214170891_b5529f5d72_o.jpg'),
    ('2019_dolomites_garda', 'Доломиты и озеро Гарда. Две недели в августе',
     2019, 'август', 'https://live.staticflickr.com/65535/49002758212_92d4418297_o.jpg'),
    ('2021_three_routes_1', 'Три коротких маршрута. Часть первая: Суздаль и Владимир',
     2021, 'август', 'https://live.staticflickr.com/65535/51892272407_cb677a6695_o.jpg'),
    ('2021_three_routes_2', 'Три коротких маршрута. Часть вторая: Коломна и Константиново',
     2021, 'август', 'https://live.staticflickr.com/65535/51740529969_7f36a1e7f4_o.jpg'),
    ('2021_three_routes_3', 'Три коротких маршрута. Часть третья: Таруса',
     2021, 'август', 'https://live.staticflickr.com/65535/51893568129_19725c3e6c_o.jpg'),
    ('2021_istanbul_nov', 'Стамбул. Три солнечных ноябрьских дня',
     2021, 'ноябрь', 'https://live.staticflickr.com/65535/51708667204_6e57a42a07_o.jpg'),
    ('2022_istanbul_oct', 'Октябрь в Стамбуле',
     2022, 'октябрь', 'https://live.staticflickr.com/65535/52482440583_c003da0526_o.jpg'),
    ('2023_armenia1', 'Армения. Знакомство длиной в тысячу километров',
     2023, 'апрель', 'https://live.staticflickr.com/65535/53065578884_082c55db69_o.jpg'),
    ('2023_elbrus', 'Неделя в Приэльбрусье',
     2023, 'август', 'https://live.staticflickr.com/65535/53461347506_0ea082387a_o.jpg'),
    ('2024_armenia2', 'Возвращение в Армению. Год спустя',
     2024, 'апрель', 'https://live.staticflickr.com/65535/53726915126_c6bc16b367_o.jpg'),
    ('2024_venice_dolomites', 'Венеция и Доломитовые Альпы. Горячее дыхание августа',
     2024, 'август', 'https://live.staticflickr.com/65535/54027023736_20b39efefe_o.jpg'),
    ('2025_rome', 'Рим. Пять дней в январе',
     2025, 'январь', 'https://live.staticflickr.com/65535/54300792337_712cb31068_o.jpg'),
]

def esc(s):
    return html.escape(s, quote=False)

# group by year
years = {}
for r in REPORTS:
    years.setdefault(r[2], []).append(r)

sections_html = []
for year in sorted(years.keys()):
    cards = []
    for file, title, y, month, photo in years[year]:
        cards.append(f'''      <a class="card" href="{esc(file)}.html">
        <div class="card-photo" style="background-image:url('{esc(photo)}')"></div>
        <div class="card-body">
          <div class="card-month">{esc(month)}</div>
          <div class="card-title">{esc(title)}</div>
        </div>
      </a>''')
    sections_html.append(f'''    <section class="year-group">
      <div class="year-label">{year}</div>
      <div class="cards">
{chr(10).join(cards)}
      </div>
    </section>''')

content = '\n'.join(sections_html)

page = f'''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Дневники наших путешествий</title>
<style>
  :root {{
    --bg: #fbfaf7;
    --text: #2b2925;
    --text-soft: #5c584f;
    --accent: #8a6d3b;
    --accent-soft: #c9a876;
    --line: #e8e3d8;
    --serif: Georgia, "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Palatino, serif;
    --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }}
  * {{ box-sizing: border-box; }}
  html {{ scroll-behavior: smooth; }}
  body {{
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: var(--serif);
    font-size: 19px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }}
  .wrap {{
    width: 92%;
    max-width: 1000px;
    margin: 0 auto;
    padding: 4vw 0 8vw;
  }}
  header.masthead {{
    max-width: none;
    margin: 0 0 4rem;
    padding: 8vw 0 3.5rem;
    text-align: center;
    border-bottom: 1px solid var(--line);
    background:
      linear-gradient(rgba(251,250,247,0.6), rgba(251,250,247,0.6)),
      url('https://farm5.staticflickr.com/4834/31823487168_4804b1bf8f_o.jpg') center 0% / cover no-repeat;
  }}
  header.masthead h1 {{
    font-weight: 400;
    font-size: 2.6rem;
    line-height: 1.25;
    margin: 0 0 0.7rem;
    letter-spacing: 0.01em;
    text-shadow: 0 0 14px var(--bg), 0 0 6px var(--bg);
  }}
  header.masthead p {{
    font-family: var(--sans);
    color: var(--text-soft);
    font-size: 1.05rem;
    margin: 0 0 0.5rem;
  }}
  header.masthead .byline {{
    font-size: 1.5rem;
    color: #ffffff;
    text-shadow: 0 0 14px var(--bg), 0 0 6px var(--bg);
  }}
  .year-group {{
    margin-bottom: 2.6rem;
  }}
  .year-label {{
    font-family: var(--sans);
    font-size: 1.15rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    color: var(--accent-soft);
    margin-bottom: 0.9rem;
    padding-bottom: 0.4rem;
    border-bottom: 1px solid var(--line);
  }}
  .cards {{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.3rem;
  }}
  .card {{
    display: flex;
    flex-direction: row;
    align-items: stretch;
    text-decoration: none;
    color: inherit;
    border-radius: 10px;
    overflow: hidden;
    background: #fff;
    box-shadow: 0 1px 3px rgba(43,41,37,0.07), 0 6px 18px rgba(43,41,37,0.05);
    transition: transform 0.18s ease, box-shadow 0.18s ease;
  }}
  .card:hover {{
    transform: translateY(-3px);
    box-shadow: 0 4px 10px rgba(43,41,37,0.10), 0 14px 28px rgba(43,41,37,0.09);
  }}
  .card-photo {{
    flex: 0 0 42%;
    background-size: cover;
    background-position: center;
    background-color: var(--line);
    min-height: 132px;
  }}
  .card-body {{
    flex: 1 1 auto;
    padding: 0.9rem 1.1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }}
  .card-month {{
    font-family: var(--sans);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-size: 0.7rem;
    color: var(--accent);
    margin-bottom: 0.4rem;
  }}
  .card-title {{
    font-family: var(--serif);
    font-size: 1rem;
    line-height: 1.35;
    color: var(--text);
  }}
  footer.site-footer {{
    text-align: center;
    margin-top: 3.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--line);
    font-family: var(--sans);
    font-size: 0.78rem;
    color: var(--accent-soft);
  }}
  @media (max-width: 700px) {{
    .wrap {{ width: 90%; }}
    header.masthead h1 {{ font-size: 2rem; }}
    .cards {{ grid-template-columns: 1fr; }}
    .card {{ flex-direction: column; }}
    .card-photo {{ flex: 0 0 auto; height: 150px; }}
  }}
</style>
</head>
<body>
<div class="wrap">
  <header class="masthead">
    <h1>Дневники наших путешествий</h1>
    <p class="byline">Мы — это Вадим и Женя Королёвы</p>
  </header>

  <main>
{content}
  </main>

  <footer class="site-footer">© Вадим Королёв</footer>
</div>
</body>
</html>
'''

out_path = '/mnt/user-data/outputs/index.html'
os.makedirs(os.path.dirname(out_path), exist_ok=True)
with open(out_path, 'w', encoding='utf-8') as f:
    f.write(page)
print('written', out_path, len(page), 'bytes')
print('total cards:', len(REPORTS))
