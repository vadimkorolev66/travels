#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Converts an AWD forum travel-report RTF (already exported to LibreOffice HTML,
see convert_all.py) with square-bracket BBCode-style markup into a clean,
modern, single-file HTML page.
"""
import re, html, os

def esc(s):
    return html.escape(s, quote=False)

# Phrases that, if present shortly BEFORE a forum.awd.ru link, signal the
# link points to the author's OWN report elsewhere (keep as a pending
# placeholder to be relinked to a local file later). Otherwise forum links
# are treated as normal external links (someone else's report, a reference,
# an inspiration source, etc). We only look at a short window right before
# the link so that unrelated uses of these phrases elsewhere in a long
# paragraph don't cause false positives.
SELF_REPORT_SIGNALS = [
    'я писал', 'я уже писал', 'моем рассказе', 'моём рассказе',
    'моем отчете', 'моём отчёте', 'мой другой рассказ', 'мой прошлый рассказ',
    'у меня в рассказе', 'у меня есть рассказ', 'нашем предыдущем рассказе',
    'нашем прошлом рассказе', 'своем рассказе', 'своём рассказе',
    'своем отчете', 'своём отчёте',
]
SIGNAL_WINDOW = 120  # chars of context immediately before the link to check

# Forum emoticon codes (e.g. ":smile:") that have no image on our side --
# replaced with their plain-text "smiley on its side" equivalent.
EMOTICON_FIXES = {
    ':smile:': ':)',
}
def apply_emoticon_fixes(text):
    for code, replacement in EMOTICON_FIXES.items():
        text = text.replace(code, replacement)
    return text

# Manual one-off fixes for bare URLs typed directly in the prose (not
# wrapped in [url=]) where a nearby phrase makes a natural link caption.
# Add more tuples here as they turn up in other files.
BARE_URL_FIXES = [
    (r'экспресс-автобусом Люфтганзы – до Страсбурга \(https://www\.lufthansa\.com/ru/ru/lufthansa-express-bus\)',
     '[url=https://www.lufthansa.com/ru/ru/lufthansa-express-bus]экспресс-автобусом Люфтганзы[/url] – до Страсбурга'),
]


def clean_paragraph(p):
    t = re.sub(r'<[^>]+>', '', p)
    t = html.unescape(t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t


def extract_paragraphs(src_html_path):
    data = open(src_html_path, encoding='utf-8').read()
    body = re.search(r'<body[^>]*>(.*)</body>', data, re.S).group(1)
    raw_paras = re.findall(r'<p[^>]*>(.*?)</p>', body, re.S)
    cleaned = [clean_paragraph(p) for p in raw_paras]
    return [c for c in cleaned if c]


def extract_paragraphs_from_txt(src_txt_path):
    """Same output as extract_paragraphs() but for a plain .txt export of
    the report instead of an RTF->HTML conversion. Paragraphs are assumed
    to be separated by one or more blank lines; wrapped lines within a
    paragraph are joined with a space. Use this (via convert_any()) when
    the source is .txt rather than .rtf -- no LibreOffice step needed."""
    with open(src_txt_path, encoding='utf-8') as f:
        data = f.read()
    blocks = re.split(r'\n\s*\n', data)
    cleaned = []
    for b in blocks:
        b = re.sub(r'\s+', ' ', b).strip()
        if b:
            cleaned.append(b)
    return cleaned


def normalize_dashes(text):
    """A hyphen with a space on both sides is being used as a sentence
    dash, not to join a compound word (compound hyphens never have spaces
    around them, e.g. "Покрова-на-Нерли", "пресс-конференция", "по-новому").
    Promote it to an en dash, matching the dash style already used
    throughout these reports for this. A hyphen opening a line/quote as
    reported speech ("- Привет!") is promoted to an em dash instead,
    per standard Russian typographic convention for dialogue."""
    text = re.sub(r'(?<=\S) - (?=\S)', ' – ', text)
    text = re.sub(r'(^|[«"\n])- ', r'\1— ', text)
    return text


def fix_common_typos(text):
    # A dropped closing bracket: "[/url some more text" instead of "[/url]..."
    text = re.sub(r'\[/url(?!\])', '[/url]', text)
    # "[url=X]label[url]" used by mistake instead of "[url=X]label[/url]"
    text = re.sub(r'(\[url=[^\]]+\][^\[\]]*)\[url\]', r'\1[/url]', text)
    return text


def merge_citation_quotes(cleaned):
    """A literal "«" right before [i] and "»" right after [/i] is the
    author's own way of marking a Wikipedia-style citation, on top of
    italics. Convert every such span into a "\x00QUOTE\x00" pseudo-paragraph
    (same sentinel the plain multi-paragraph [i] merge uses below) so it
    always renders as a bordered blockquote -- whether it closes within
    the same source paragraph or spans several. Plain [i]...[/i] with no
    leading guillemet is untouched and stays as simple inline emphasis.
    """
    merged = []
    i, n = 0, len(cleaned)
    OPEN, CLOSE = '«[i]', '[/i]»'
    while i < n:
        c = cleaned[i]
        idx = c.find(OPEN)
        if idx == -1:
            merged.append(c)
            i += 1
            continue
        prefix = c[:idx].strip()
        if prefix:
            merged.append(prefix)
        lines = []
        rest = c[idx + len(OPEN):]
        close_idx = rest.find(CLOSE)
        if close_idx != -1:
            # closes within this same paragraph
            if rest[:close_idx].strip():
                lines.append(rest[:close_idx].strip())
            after = rest[close_idx + len(CLOSE):].strip()
            merged.append('\x00QUOTE\x00' + '\n'.join(lines))
            if after:
                merged.append(after)
            i += 1
            continue
        # spans further paragraphs; also tolerate a bare "[/i]" (no
        # trailing guillemet) as the close, in case of a typo
        if rest.strip():
            lines.append(rest.strip())
        i += 1
        closed = False
        after = ''
        while i < n and not closed:
            nc = cleaned[i]
            c_idx = nc.find(CLOSE)
            tag_len = len(CLOSE)
            if c_idx == -1:
                c_idx = nc.find('[/i]')
                tag_len = len('[/i]')
            if c_idx != -1:
                before = nc[:c_idx].strip()
                if before:
                    lines.append(before)
                after = nc[c_idx + tag_len:].strip()
                closed = True
                i += 1
            else:
                lines.append(nc)
                i += 1
        merged.append('\x00QUOTE\x00' + '\n'.join(lines))
        if after:
            merged.append(after)
    return merged


def apply_bare_url_fixes(text):
    for pattern, replacement in BARE_URL_FIXES:
        text = re.sub(pattern, replacement, text)
    return text

def apply_fixes(text, fixes):
    for pattern, replacement in fixes:
        text = re.sub(pattern, replacement, text)
    return text


import difflib

def strip_title_echo(cleaned, title):
    """Some source files repeat the report's title as a plain first
    paragraph before the first real content/header -- redundant with our
    own <h1>, so drop it if the first paragraph looks like the title."""
    if not cleaned:
        return cleaned
    first = cleaned[0]
    if len(first) > 200:
        return cleaned

    def norm(s):
        s = s.lower()
        s = re.sub(r'[«»".,:;!?\-–—]', ' ', s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    ratio = difflib.SequenceMatcher(None, norm(first), norm(title)).ratio()
    if ratio > 0.6:
        return cleaned[1:]
    return cleaned


TOC_LABEL_RE = re.compile(r'^\[b\]\s*(содержание|оглавление)\s*:?\s*\[/b\]$', re.I)
TOC_LINK_LINE_RE = re.compile(r'^(?:\[i\])?\[(?:url|rul)=[^\]]+\][^\[\]]+\[/url\](?:\[/i\])?$', re.S)

def strip_manual_toc(cleaned):
    """Remove an author-made "Содержание:" block followed by a run of
    [url=...]Chapter[/url] lines -- we generate our own table of contents,
    so a manual one in the body would just be a redundant, unstyled list."""
    out = []
    i, n = 0, len(cleaned)
    while i < n:
        c = cleaned[i]
        if TOC_LABEL_RE.match(c):
            j = i + 1
            while j < n and TOC_LINK_LINE_RE.match(cleaned[j]):
                j += 1
            if j > i + 1:  # at least one link line followed the label
                i = j
                continue
        out.append(c)
        i += 1
    return out


def fix_dangling_header_bold(cleaned):
    """One source file leaves the [b] before a [size=N] header open across
    into the next paragraph (a route-summary line), only closing it there
    with a bare trailing [/b] -- e.g.:
        "[b][size=150]Day one.[/size]"
        "Village A - Village B - Village C[/b]"
    Splits the dangling [/b] off into its own properly-closed [b]...[/b]
    paragraph so it flows through the normal header/sub-heading detection
    instead of leaking a stray bracket tag into the output.
    """
    out = []
    i, n = 0, len(cleaned)
    while i < n:
        c = cleaned[i]
        if (c.count('[b]') > c.count('[/b]') and '[size=' in c
                and i + 1 < n):
            nc = cleaned[i + 1]
            if nc.count('[/b]') > nc.count('[b]') and nc.rstrip().endswith('[/b]'):
                idx = nc.rindex('[/b]')
                before = nc[:idx].strip()
                after = nc[idx + len('[/b]'):].strip()
                out.append(c)
                if before:
                    out.append(f'[b]{before}[/b]')
                if after:
                    out.append(after)
                i += 2
                continue
        out.append(c)
        i += 1
    return out


def find_unmatched_open_start(text, open_tag, close_tag):
    """Index where the final still-open `open_tag` span begins, accounting
    for any earlier occurrences of the tag that are already balanced
    within `text` (so only the trailing unmatched one is used as the
    split point). Returns -1 if the tag is fully balanced in `text`."""
    depth = 0
    last_zero_to_one = -1
    i, n = 0, len(text)
    while i < n:
        if text.startswith(open_tag, i):
            if depth == 0:
                last_zero_to_one = i
            depth += 1
            i += len(open_tag)
        elif text.startswith(close_tag, i):
            depth = max(0, depth - 1)
            i += len(close_tag)
        else:
            i += 1
    return last_zero_to_one if depth > 0 else -1


def merge_multiparagraph_span(cleaned, tag, sentinel):
    """
    Generic version of the multi-paragraph-span merge: [TAG]...[/TAG]
    normally opens and closes within one paragraph. Occasionally it spans
    several source paragraphs (a poem, a dialogue, a right-aligned
    epigraph): either a standalone "[TAG]" paragraph opens it and a
    standalone "[/TAG]" closes it several paragraphs later, or the open tag
    is a prefix on the first line. This collapses any such run into a
    single pseudo-paragraph starting with `sentinel`, lines joined by "\n",
    so the main loop can render it as one block with line breaks preserved.
    """
    open_tag, close_tag = f'[{tag}]', f'[/{tag}]'
    merged = []
    i = 0
    n = len(cleaned)
    while i < n:
        c = cleaned[i]
        open_count = c.count(open_tag)
        close_count = c.count(close_tag)
        if open_count > close_count:
            idx = find_unmatched_open_start(c, open_tag, close_tag)
            prefix = c[:idx].strip()
            if prefix:
                merged.append(prefix)
            lines = []
            first_line = c[idx + len(open_tag):].strip()
            if first_line:
                lines.append(first_line)
            i += 1
            closed = False
            after = ''
            while i < n and not closed:
                nc = cleaned[i]
                if close_tag in nc:
                    idx2 = nc.index(close_tag)
                    before = nc[:idx2].strip()
                    if before:
                        lines.append(before)
                    after = nc[idx2 + len(close_tag):].strip()
                    closed = True
                    i += 1
                else:
                    lines.append(nc)
                    i += 1
            merged.append(sentinel + '\n'.join(lines))
            if after:
                merged.append(after)
            continue
        else:
            merged.append(c)
            i += 1
    return merged


def merge_multiparagraph_quotes(cleaned):
    return merge_multiparagraph_span(cleaned, 'i', '\x00QUOTE\x00')


def merge_multiparagraph_right(cleaned):
    return merge_multiparagraph_span(cleaned, 'text_right', '\x00RIGHT\x00')


def inline_simple(text):
    # Inline [b]...[/b] emphasis in running prose looked odd once lifted out
    # of the forum's own styling context, so it's stripped to plain text
    # everywhere except structural chapter headers (handled separately via
    # HEADER_RE, before this function ever sees that text).
    text = re.sub(r'\[b\](.*?)\[/b\]', r'\1', text, flags=re.S)
    text = re.sub(r'\[i\](.*?)\[/i\]', r'<em>\1</em>', text, flags=re.S)
    # A stray [size=N]...[/size] used mid-sentence (not as a whole-paragraph
    # header, which HEADER_RE already consumed before this runs) -- just
    # keep the text, drop the sizing.
    text = re.sub(r'\[size=\d+\](.*?)\[/size\]', r'\1', text, flags=re.S)
    return text


LOCAL_LINK_RE = re.compile(r'^[\w.\-]+\.html(#.*)?$')

def normalize_link(link):
    """Fix protocol typos/omissions on external URLs (seen in the source:
    "hhtps://..." and a bare "www.example.com" with no protocol at all).
    Leaves our own local "2019_key.html" / "#anchor" links untouched."""
    link = re.sub(r'^hhtps://', 'https://', link, flags=re.I)
    link = re.sub(r'^hhttp://', 'http://', link, flags=re.I)
    if re.match(r'^https?://', link, re.I) or link.startswith('#') or LOCAL_LINK_RE.match(link):
        return link
    return 'https://' + link


def inline_convert(text):
    """Convert inline bracket tags (b, i, url, bare url) within a text run."""

    def url_eq_sub(m):
        # [url=link]label[/url]
        link = normalize_link(m.group(1).strip())
        label = inline_simple(m.group(2))
        if 'forum.awd.ru' in link:
            window = text[max(0, m.start() - SIGNAL_WINDOW):m.start()].lower()
            if any(sig in window for sig in SELF_REPORT_SIGNALS):
                return (f'<a href="#" class="internal-link-pending" data-original-href="{esc(link)}" '
                        f'title="Ссылка на другой рассказ автора — будет заменена на локальный файл">{label}</a>')
        return f'<a href="{esc(link)}" target="_blank" rel="noopener noreferrer">{label}</a>'

    def url_bare_sub(m):
        # [url]http://...[/url] -- link text is the URL itself
        link = normalize_link(m.group(1).strip())
        return f'<a href="{esc(link)}" target="_blank" rel="noopener noreferrer">{esc(link)}</a>'

    text = re.sub(r'\[url=([^\]]*)\](.*?)\[/url\]', url_eq_sub, text, flags=re.S)
    text = re.sub(r'\[url\](.*?)\[/url\]', url_bare_sub, text, flags=re.S)
    text = inline_simple(text)
    return text


def yt_embed(url):
    m = re.search(r'(?:v=|youtu\.be/)([A-Za-z0-9_-]{6,})', url)
    vid = m.group(1) if m else ''
    if vid:
        return (f'<div class="video-embed"><iframe src="https://www.youtube.com/embed/{vid}" '
                f'title="video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; '
                f'encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe></div>')
    return f'<p><a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{esc(url)}</a></p>'


# Chapter headers are usually "[b][size=N]Title[/size][/b]", but some
# reports drop the closing [/b] (a source typo) or skip [b] entirely and
# rely on [size=N] alone -- both b tags are therefore optional here.
HEADER_RE = re.compile(r'^(?:\[b\])?\[size=\d+\]\s*(.*?)\s*\[/size\]\s*(?:\[/b\])?$', re.S)
IMG_RE = re.compile(r'^\[img\](.*?)\[/img\](?:\[/url\])?[.,;:!?\s]*$', re.S)
IMG_UNCLOSED_RE = re.compile(r'^\[img\](https?://\S+)$')
MEDIA_RE = re.compile(r'^\[media\](.*?)\[/media\][.,;:!?\s]*$', re.S)
FIN_RE = re.compile(r'^F\s+I\s+N$')

# Some reports mark chapter headers with bold + ALL CAPS instead of a
# [size=] tag, e.g. "[b]ВЕНЕЦИЯ. ДЕНЬ ПЕРВЫЙ.[/b]". Only used as a fallback
# when HEADER_RE doesn't match, and only for paragraphs whose letters are
# entirely uppercase, so ordinary short bold labels (like a sub-heading
# "[b]TGV Paris - Vannes:[/b]") aren't mistaken for chapter headers.
ALLCAPS_HEADER_RE = re.compile(r'^\[b\]([^\[\]]{1,80})\[/b\][.\s]*$', re.S)

CONNECTOR_WORDS = {'он', 'она', 'оно', 'они', 'же', 'и', 'в', 'на', 'с', 'у', 'к',
                    'от', 'до', 'для', 'по', 'а', 'но', 'или', 'не', 'то'}

def is_all_caps_label(text):
    words = re.findall(r'[a-zа-яёA-ZА-ЯЁ]+', text)
    if not words:
        return False
    has_upper_word = False
    for w in words:
        if len(w) >= 2 and w == w.upper():
            has_upper_word = True
        elif w.lower() in CONNECTOR_WORDS:
            continue
        else:
            return False
    return has_upper_word

# Proper nouns that need their capital letter restored after an ALL-CAPS
# header is converted to sentence case (e.g. "ПРОЩАНИЕ С БОЛОНЬЕЙ" ->
# "Прощание с болоньей" -> "Прощание с Болоньей"). Extend as needed when
# new ALL-CAPS-header files turn up other place names.
PROPER_NOUN_FIXES = {
    'милан': 'Милан', 'болонья': 'Болонья', 'болоньей': 'Болоньей', 'феррара': 'Феррара',
    'верона': 'Верона', 'венеция': 'Венеция', 'падуя': 'Падуя',
    'тбилиси': 'Тбилиси', 'гергети': 'Гергети', 'гареджа': 'Гареджа', 'давид': 'Давид',
    'сигнахи': 'Сигнахи', 'греми': 'Греми', 'некреси': 'Некреси', 'киндзмараули': 'Киндзмараули',
    'джвари': 'Джвари', 'мцхета': 'Мцхета', 'уплисцихе': 'Уплисцихе', 'светицховели': 'Светицховели',
    'мало': 'Мало', 'сен': 'Сен', 'мишель': 'Мишель', 'тер': 'Тер', 'ванн': 'Ванн', 'ван': 'Ван',
}

def sentence_case_header(text):
    """Convert an ALL-CAPS header to normal sentence case, so it matches
    the visual style of the [size=]-based headers elsewhere."""
    t = text.lower()
    t = re.sub(r'(^\s*|[.!?]\s+[«"]?\s*)([a-zа-яё])',
                lambda m: m.group(1) + m.group(2).upper(), t)
    def fix_word(m):
        return PROPER_NOUN_FIXES.get(m.group(0).lower(), m.group(0))
    t = re.sub(r'[a-zа-яёА-ЯЁ]+', fix_word, t)
    return t

# A paragraph that OPENS with [b]...[/b] and has only a short trailing bit
# of plain text after it (or nothing at all) is a standalone label/caption
# rather than emphasis inside a running sentence -- e.g. a little heading
# like "[b]TGV Paris - Vannes:[/b]" introducing the next few paragraphs.
# Rendered as a small accent sub-heading (not bold). Thresholds are
# deliberately tight so real emphasised words/names inside normal sentences
# (which start mid-paragraph, not at position 0) don't get caught here.
SUBHEAD_RE = re.compile(r'^\[b\]([^\[\]]{1,110})\[/b\]([^\[\]]{0,80})$', re.S)


def build_body(cleaned):
    out = []
    in_list = False
    headers = []
    subheads = []
    slug_seen = {}

    def make_id(title_text):
        base = re.sub(r'[^\w\-]+', '-', title_text.strip().lower())
        base = re.sub(r'-+', '-', base).strip('-') or 'section'
        k = slug_seen.get(base, 0)
        slug_seen[base] = k + 1
        return base if k == 0 else f'{base}-{k}'

    def close_list():
        nonlocal in_list
        out.append('</ul>')
        in_list = False

    def render_quote_lines(lines):
        """Join quote lines with <br>, but break out any line that's
        actually a standalone image into its own <figure> (rare, but
        source citations occasionally have a photo embedded mid-quote)."""
        pieces = []
        text_buf = []
        def flush():
            if text_buf:
                pieces.append('<p>' + '<br>\n'.join(text_buf) + '</p>')
                text_buf.clear()
        for line in lines:
            im = IMG_RE.match(line)
            if im:
                flush()
                src = im.group(1).strip()
                pieces.append(f'<figure class="photo"><img data-src="{esc(src)}" alt="" class="lazy-photo"><noscript><img src="{esc(src)}" alt="" loading="lazy"></noscript></figure>')
            else:
                text_buf.append(inline_convert(line))
        flush()
        return '\n'.join(pieces)

    def render_paragraph(c):
        # quote block (single or multi-paragraph, merged upstream)
        if c.startswith('\x00QUOTE\x00'):
            lines = c[len('\x00QUOTE\x00'):].split('\n')
            out.append(f'<blockquote class="citation">{render_quote_lines(lines)}</blockquote>')
            return

        # right-aligned epigraph (single or multi-paragraph, merged upstream)
        if c.startswith('\x00RIGHT\x00'):
            lines = c[len('\x00RIGHT\x00'):].split('\n')
            rendered = '<br>\n'.join(inline_convert(line) for line in lines)
            out.append(f'<p class="epigraph">{rendered}</p>')
            return

        hm = HEADER_RE.match(c)
        if not hm:
            am = ALLCAPS_HEADER_RE.match(c)
            if am and is_all_caps_label(am.group(1)):
                hm = am
        if hm:
            raw_title = hm.group(1)
            if is_all_caps_label(raw_title):
                raw_title = sentence_case_header(raw_title)
            title_html = inline_convert(raw_title).strip()
            plain_title = re.sub(r'<[^>]+>', '', title_html)
            hid = make_id(plain_title)
            headers.append((hid, plain_title))
            out.append(f'<h2 id="{hid}">{title_html}</h2>')
            return

        im = IMG_RE.match(c)
        if not im:
            im = IMG_UNCLOSED_RE.match(c)
        if im:
            src = im.group(1).strip()
            out.append(f'<figure class="photo"><img data-src="{esc(src)}" alt="" class="lazy-photo"><noscript><img src="{esc(src)}" alt="" loading="lazy"></noscript></figure>')
            return

        mm = MEDIA_RE.match(c)
        if mm:
            out.append(yt_embed(mm.group(1).strip()))
            return

        if FIN_RE.match(c):
            out.append('<p class="fin">F&nbsp;&nbsp;I&nbsp;&nbsp;N</p>')
            return

        sh = SUBHEAD_RE.match(c)
        if sh:
            label = (sh.group(1) + sh.group(2)).strip()
            subheads.append(label)
            out.append(f'<p class="subhead">{esc(label)}</p>')
            return

        out.append(f'<p>{inline_convert(c)}</p>')

    for c in cleaned:
        if c == '[list]':
            out.append('<ul class="summary-list">')
            in_list = True
            continue

        if in_list:
            if c.startswith('[*]'):
                if '[/list]' in c:
                    idx = c.index('[/list]')
                    item_text = c[len('[*]'):idx].strip()
                    out.append(f'  <li>{inline_convert(item_text)}</li>')
                    close_list()
                    trailing = c[idx + len('[/list]'):].strip()
                    if trailing:
                        render_paragraph(trailing)
                else:
                    item_text = c[len('[*]'):].strip()
                    out.append(f'  <li>{inline_convert(item_text)}</li>')
                continue
            else:
                # list ended without a [*]-prefixed closer; the [/list] tag
                # may be attached to this (non-list-item) paragraph instead
                close_list()
                if '[/list]' in c:
                    idx = c.index('[/list]')
                    before = c[:idx].strip()
                    after = c[idx + len('[/list]'):].strip()
                    combined = (before + ' ' + after).strip()
                    if combined:
                        render_paragraph(combined)
                    continue
                # else fall through: render c normally below

        if c == '[/list]':
            continue

        render_paragraph(c)

    if in_list:
        close_list()

    return '\n'.join(out), headers, subheads


PAGE_TEMPLATE = '''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<link rel="icon" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+CjxkZWZzPgo8bGluZWFyR3JhZGllbnQgaWQ9InNreSIgeDE9IjAiIHkxPSIwIiB4Mj0iMCIgeTI9IjEiPgo8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjM2QyZjVlIi8+CjxzdG9wIG9mZnNldD0iNTUlIiBzdG9wLWNvbG9yPSIjYTg0NTZiIi8+CjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2U4NzM0YSIvPgo8L2xpbmVhckdyYWRpZW50Pgo8L2RlZnM+CjxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSIyNCIgaGVpZ2h0PSIxMiIgZmlsbD0idXJsKCNza3kpIi8+CjxyZWN0IHg9IjAiIHk9IjEyIiB3aWR0aD0iMjQiIGhlaWdodD0iMTIiIGZpbGw9IiMyMzRiNzMiLz4KPHJlY3QgeD0iMy41IiB5PSI4LjUiIHdpZHRoPSIxNyIgaGVpZ2h0PSIxMSIgcng9IjIuMiIgZmlsbD0iI2Y3ZWNjNCIvPgo8cmVjdCB4PSI5IiB5PSI1LjUiIHdpZHRoPSI2IiBoZWlnaHQ9IjMuNCIgcng9IjEiIGZpbGw9IiNmN2VjYzQiLz4KPGNpcmNsZSBjeD0iMTIiIGN5PSIxNCIgcj0iMy42IiBmaWxsPSIjN2E1YTMwIi8+CjxjaXJjbGUgY3g9IjEyIiBjeT0iMTQiIHI9IjIuMSIgZmlsbD0iI2Y3ZWNjNCIvPgo8L3N2Zz4=">
<link rel="apple-touch-icon" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+CjxkZWZzPgo8bGluZWFyR3JhZGllbnQgaWQ9InNreSIgeDE9IjAiIHkxPSIwIiB4Mj0iMCIgeTI9IjEiPgo8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjM2QyZjVlIi8+CjxzdG9wIG9mZnNldD0iNTUlIiBzdG9wLWNvbG9yPSIjYTg0NTZiIi8+CjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2U4NzM0YSIvPgo8L2xpbmVhckdyYWRpZW50Pgo8L2RlZnM+CjxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSIyNCIgaGVpZ2h0PSIxMiIgZmlsbD0idXJsKCNza3kpIi8+CjxyZWN0IHg9IjAiIHk9IjEyIiB3aWR0aD0iMjQiIGhlaWdodD0iMTIiIGZpbGw9IiMyMzRiNzMiLz4KPHJlY3QgeD0iMy41IiB5PSI4LjUiIHdpZHRoPSIxNyIgaGVpZ2h0PSIxMSIgcng9IjIuMiIgZmlsbD0iI2Y3ZWNjNCIvPgo8cmVjdCB4PSI5IiB5PSI1LjUiIHdpZHRoPSI2IiBoZWlnaHQ9IjMuNCIgcng9IjEiIGZpbGw9IiNmN2VjYzQiLz4KPGNpcmNsZSBjeD0iMTIiIGN5PSIxNCIgcj0iMy42IiBmaWxsPSIjN2E1YTMwIi8+CjxjaXJjbGUgY3g9IjEyIiBjeT0iMTQiIHI9IjIuMSIgZmlsbD0iI2Y3ZWNjNCIvPgo8L3N2Zz4=">
<style>
  :root {{
    --bg: #fbfaf7;
    --text: #2b2925;
    --text-soft: #5c584f;
    --accent: #8a6d3b;
    --accent-soft: #c9a876;
    --line: #e8e3d8;
    --serif: Georgia, "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Palatino, serif;
    --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }}
  * {{ box-sizing: border-box; }}
  html {{ scroll-behavior: smooth; }}
  body {{
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: var(--serif);
    font-size: 21px;
    line-height: 1.75;
    -webkit-font-smoothing: antialiased;
  }}
  .wrap {{
    width: 86%;
    max-width: 1400px;
    margin: 0 auto;
    padding: 4vw 0 8vw;
  }}
  nav.toc,
  article > p,
  article > h2,
  article > ul.summary-list,
  article > blockquote.citation {{
    max-width: 840px;
    margin-left: auto;
    margin-right: auto;
  }}
  header.masthead {{
    max-width: none;
    padding: 8vw 0 4vw;
    text-align: center;
    border-bottom: 1px solid var(--line);
    margin-bottom: 3rem;
    background:
      linear-gradient(rgba(251,250,247,0.6), rgba(251,250,247,0.6)),
      url('{header_photo}') center {header_photo_pos} / cover no-repeat;
  }}
  header.masthead h1 {{
    font-family: var(--serif);
    font-weight: 400;
    font-size: 2.4rem;
    line-height: 1.3;
    margin: 0;
    letter-spacing: 0.01em;
    text-shadow: 0 0 14px var(--bg), 0 0 6px var(--bg);
  }}
  nav.toc {{
    background: #f4f1ea;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 1.6rem 1.8rem;
    margin-top: 0;
    margin-bottom: 3.5rem;
    font-family: var(--sans);
  }}
  nav.toc summary {{
    cursor: pointer;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    font-size: 0.8rem;
    color: var(--accent);
  }}
  nav.toc ul {{
    list-style: none;
    margin: 1.8rem 0 0;
    padding: 0;
    columns: 2;
    column-gap: 2rem;
  }}
  nav.toc li {{ margin: 0 0 0.85rem; break-inside: avoid; }}
  nav.toc a {{
    color: var(--text);
    text-decoration: none;
    line-height: 1.3;
    font-size: 0.98rem;
    border-bottom: 1px solid transparent;
  }}
  nav.toc a:hover {{ border-bottom-color: var(--accent-soft); color: var(--accent); }}
  h2 {{
    font-family: var(--serif);
    font-weight: 400;
    font-size: 1.9rem;
    margin: 3.9rem 0 1.4rem;
    padding-top: 0.2rem;
    color: var(--text);
    position: relative;
  }}
  h2::before {{
    content: "";
    display: block;
    width: 46px;
    height: 2px;
    background: var(--accent-soft);
    margin-bottom: 1.1rem;
  }}
  p {{
    margin: 0 0 1.5rem;
    text-align: justify;
    hyphens: auto;
    -webkit-hyphens: auto;
  }}
  strong {{ font-weight: 600; color: var(--text); }}
  em {{ font-style: italic; color: var(--text-soft); }}
  a {{ color: var(--accent); text-decoration-color: var(--accent-soft); }}
  a:hover {{ color: #6b5228; }}
  a.internal-link-pending {{
    color: var(--text-soft);
    border-bottom: 1px dashed var(--accent-soft);
    text-decoration: none;
    cursor: default;
  }}
  ul.summary-list {{
    background: #f4f1ea;
    border-radius: 10px;
    padding: 1.6rem 1.8rem 1.6rem 2.4rem;
    margin: 0 0 3rem;
  }}
  ul.summary-list li {{ margin-bottom: 0.7rem; }}
  ul.summary-list li:last-child {{ margin-bottom: 0; }}
  blockquote.citation {{
    margin: 2rem 0;
    padding: 0.2rem 0 0.2rem 1.5rem;
    border-left: 3px solid var(--accent-soft);
    font-style: italic;
    color: var(--text-soft);
  }}
  blockquote.citation p {{
    text-align: left;
    hyphens: none;
    -webkit-hyphens: none;
  }}
  figure.photo {{ margin: 2.6rem 0; }}
  figure.photo img {{
    display: block;
    max-width: 100%;
    width: auto;
    height: auto;
    margin: 0 auto;
    border-radius: 6px;
    box-shadow: 0 1px 3px rgba(43,41,37,0.08), 0 8px 24px rgba(43,41,37,0.06);
  }}
  img.lazy-photo {{
    opacity: 0;
    transition: opacity 0.4s ease;
    min-height: 40px;
    background: var(--line);
  }}
  img.lazy-photo.loaded {{ opacity: 1; }}
  .video-embed {{
    position: relative;
    width: 100%;
    padding-top: 56.25%;
    margin: 2.2rem 0;
    border-radius: 6px;
    overflow: hidden;
    background: #000;
  }}
  .video-embed iframe {{
    position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;
  }}
  p.epigraph {{
    text-align: right;
    hyphens: none;
    -webkit-hyphens: none;
    font-style: italic;
    color: var(--text-soft);
    margin-top: 0;
    margin-bottom: 3rem;
  }}
  p.fin {{
    text-align: center;
    margin-top: 4rem;
    padding-top: 2.2rem;
    border-top: 1px solid var(--line);
    font-family: var(--sans);
    letter-spacing: 0.3em;
    font-size: 0.85rem;
    color: var(--text-soft);
  }}
  p.subhead {{
    text-align: left;
    hyphens: none;
    -webkit-hyphens: none;
    font-family: var(--sans);
    font-weight: 500;
    font-size: 0.8rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--accent);
    margin-top: 2.2rem;
    margin-bottom: 0.6rem;
  }}
  @media (max-width: 900px) {{
    .wrap {{ width: 88%; }}
  }}
  @media (max-width: 640px) {{
    body {{ font-size: 17.5px; }}
    .wrap {{ width: 90%; padding: 10vw 0 16vw; }}
    header.masthead h1 {{ font-size: 1.85rem; }}
    nav.toc ul {{ columns: 1; }}
  }}
</style>
</head>
<body>
<div class="wrap">
  <header class="masthead">
    <h1>{title}</h1>
  </header>

  <nav class="toc">
    <details open>
      <summary>Содержание</summary>
      <ul>
{nav_items}
      </ul>
    </details>
  </nav>

  <article>
{content_html}
  </article>
</div>
<script>
(function() {{
  var pending = []; // images that entered the buffer zone, not yet loading/loaded
  var loading = false;

  function distanceFromViewport(img) {{
    var rect = img.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    if (rect.bottom < 0) return -rect.bottom;      // above viewport
    if (rect.top > vh) return rect.top - vh;        // below viewport
    return 0;                                       // on screen right now
  }}

  function pickNext() {{
    if (pending.length === 0) return null;
    var bestIdx = 0, bestDist = Infinity;
    for (var i = 0; i < pending.length; i++) {{
      var d = distanceFromViewport(pending[i]);
      if (d < bestDist) {{
        bestDist = d;
        bestIdx = i;
        if (d === 0) break; // already on screen -- can't beat that
      }}
    }}
    return pending.splice(bestIdx, 1)[0];
  }}

  function processQueue() {{
    if (loading) return;
    var img = pickNext();
    if (!img) return;
    loading = true;
    loadImage(img, img.getAttribute('data-src'));
  }}

  function loadImage(img, src) {{
    img.onload = function() {{
      img.classList.add('loaded');
      img.removeAttribute('data-src');
      loading = false;
      setTimeout(processQueue, 90);
    }};
    img.onerror = function() {{
      // Flickr (or the network) hiccuped on this one request -- don't give
      // up on it and don't block everything else behind it. Free the
      // queue immediately, and let this image rejoin the pending pool
      // after a short, growing backoff so it gets picked up again.
      loading = false;
      var attempt = (img._retryCount || 0) + 1;
      img._retryCount = attempt;
      var delay = Math.min(500 * attempt, 5000);
      setTimeout(function() {{
        pending.push(img);
        processQueue();
      }}, delay);
      processQueue();
    }};
    img.src = src;
  }}

  // Images join the pending pool once they're within reach; every time a
  // slot frees up, pickNext() re-checks CURRENT positions and grabs
  // whichever pending image is closest to (or actually on) screen right
  // now -- so a fast scroll or scrollbar drag doesn't leave visible
  // photos stuck behind everything the scroll happened to pass over.
  var observer = new IntersectionObserver(function(entries) {{
    entries.forEach(function(entry) {{
      if (entry.isIntersecting) {{
        observer.unobserve(entry.target);
        pending.push(entry.target);
        processQueue();
      }}
    }});
  }}, {{ rootMargin: '600px 0px', threshold: 0.01 }});

  document.querySelectorAll('img.lazy-photo[data-src]').forEach(function(img) {{
    observer.observe(img);
  }});
}})();

(function() {{
  // Clicking a table-of-contents link jumps to the right spot right away,
  // but as images below/around it finish loading, the page grows and the
  // target visually drifts. Re-run the scroll a few times over the next
  // couple of seconds to self-correct, stopping the moment the person
  // scrolls on their own.
  var pendingCorrections = [];
  function cancelCorrections() {{
    pendingCorrections.forEach(clearTimeout);
    pendingCorrections = [];
  }}
  ['wheel', 'touchmove', 'keydown'].forEach(function(evt) {{
    document.addEventListener(evt, cancelCorrections, {{ passive: true }});
  }});
  document.querySelectorAll('nav.toc a[href^="#"]').forEach(function(link) {{
    link.addEventListener('click', function(e) {{
      var id = link.getAttribute('href').slice(1);
      var target = document.getElementById(id);
      if (!target) return;
      e.preventDefault();
      cancelCorrections();
      history.pushState(null, '', '#' + id);
      [0, 80, 200, 400, 800, 1500, 2500, 4000].forEach(function(delay) {{
        pendingCorrections.push(setTimeout(function() {{
          target.scrollIntoView({{ block: 'start' }});
        }}, delay));
      }});
    }});
  }});
}})();
</script>
</body>
</html>
'''


def convert(src_path, title, out_path, extra_fixes=None, header_photo=None, header_photo_pos='40%'):
    if src_path.lower().endswith('.txt'):
        cleaned = extract_paragraphs_from_txt(src_path)
    else:
        cleaned = extract_paragraphs(src_path)
    cleaned = strip_title_echo(cleaned, title)
    cleaned = strip_manual_toc(cleaned)
    cleaned = fix_dangling_header_bold(cleaned)
    cleaned = [fix_common_typos(c) for c in cleaned]
    cleaned = [apply_bare_url_fixes(c) for c in cleaned]
    if extra_fixes:
        cleaned = [apply_fixes(c, extra_fixes) for c in cleaned]
        # extra_fixes may inject a "\x00SPLIT\x00" marker to break one
        # source paragraph into several (e.g. pulling a label out into its
        # own heading-eligible paragraph); expand those here.
        split_cleaned = []
        for c in cleaned:
            if '\x00SPLIT\x00' in c:
                split_cleaned.extend(p for p in c.split('\x00SPLIT\x00') if p.strip())
            else:
                split_cleaned.append(c)
        cleaned = split_cleaned
        # extra_fixes may also mark a whole paragraph "\x00DELETE\x00" to
        # drop it (e.g. its standalone link got folded into the sentence
        # right before it).
        cleaned = [c for c in cleaned if c != '\x00DELETE\x00']
        # ...or end a paragraph with "\x00MERGE_NEXT\x00" to fold the very
        # next paragraph into it (e.g. a one-line "Ticket here." followed
        # by a short unrelated-looking continuation sentence that should
        # really read as one paragraph).
        merge_cleaned = []
        i = 0
        while i < len(cleaned):
            c = cleaned[i]
            if c.endswith('\x00MERGE_NEXT\x00') and i + 1 < len(cleaned):
                combined = c[:-len('\x00MERGE_NEXT\x00')].rstrip() + ' ' + cleaned[i + 1]
                merge_cleaned.append(combined)
                i += 2
            else:
                merge_cleaned.append(c)
                i += 1
        cleaned = merge_cleaned
    cleaned = [normalize_dashes(c) for c in cleaned]
    cleaned = [apply_emoticon_fixes(c) for c in cleaned]
    cleaned = merge_citation_quotes(cleaned)
    cleaned = merge_multiparagraph_quotes(cleaned)
    cleaned = merge_multiparagraph_right(cleaned)

    content_html, headers, subheads = build_body(cleaned)
    nav_items = '\n'.join(f'    <li><a href="#{hid}">{esc(t)}</a></li>' for hid, t in headers)

    page = PAGE_TEMPLATE.format(title=esc(title), nav_items=nav_items, content_html=content_html,
                                 header_photo=header_photo or '', header_photo_pos=header_photo_pos)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(page)

    # sanity report (scan article content only, not the <script>/<style>
    # boilerplate, which legitimately contains bracket-like CSS/JS syntax
    # such as the img[data-src] attribute selector)
    article_only = re.search(r'<article>(.*)</article>', page, re.S)
    scan_text = article_only.group(1) if article_only else page
    leftover = re.findall(r'\[/?[a-zA-Z*][^\]]*\]', scan_text)
    return {
        'headers': headers,
        'subheads': subheads,
        'blocks': len(cleaned),
        'leftover_tags': leftover,
        'out_path': out_path,
    }
