# -*- coding: utf-8 -*-
"""
Cross-reference fixes: links between the 21 reports themselves, found by
matching forum.awd.ru thread IDs and link labels against the other reports'
titles/topics. Repoints existing forum links to the local sibling file
where confirmed, and adds a local link where the reference was plain text.
"""
import re

ISTANBUL_OCT_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=593&t=406861#p10669090\]Первый\[/url\]',
     '[url=2021_istanbul_nov.html]Первый[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=593&t=406861#p10669090\]'
     r'Стамбул\. Три солнечных ноябрьских дня\.\[/url\]',
     '[url=2021_istanbul_nov.html]Стамбул. Три солнечных ноябрьских дня.[/url]'),
]

VENICE_DOLOMITES_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=616&t=427369\]прошлогоднего Приэльбрусья\[/url\]',
     '[url=2023_elbrus.html]прошлогоднего Приэльбрусья[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=345966&p=8771424#p8771318\]описывая Венецию\[/url\]',
     '[url=2018_north_italy.html#венеция-день-первый]описывая Венецию[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=9804391#p9804391\]в своем отчете про прошлый визит в Доломиты\[/url\]',
     '[url=2019_dolomites_garda.html]в своем отчете про прошлый визит в Доломиты[/url]'),
]

NORMANDY_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=9040394#p9040394\]отчету по Швейцарии\[/url\]',
     '[url=2018_switzerland.html]отчету по Швейцарии[/url]'),
    (r'\[url= https://forum\.awd\.ru/viewtopic\.php\?p=8056574#p8056574\]писал здесь пару лет назад\[/url\]',
     '[url=2017_bretagne.html]писал здесь пару лет назад[/url]'),
    (r'пересаживаемся по Франкфурте,',
     'пересаживаемся во Франкфурте,'),
]

BAVARIA_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=11976712#p11976712\]чуть более полугода назад\[/url\]',
     '[url=2014_salzburg.html]чуть более полугода назад[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=8230996#p8230996\]добро пожаловать\[/url\]',
     '[url=2017_alps.html]добро пожаловать[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=434159#p12041613\]январского Рима\[/url\]',
     '[url=2025_rome.html]январского Рима[/url]'),
]

ROME_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=11945794#p11945794\]в августе\[/url\]',
     '[url=2024_venice_dolomites.html]в августе[/url]'),
]

DOLOMITES_GARDA_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=345966&p=8770478#p8770478\]здесь в моем рассказе\[/url\]',
     '[url=2018_north_italy.html#верона]здесь в моем рассказе[/url]'),
]

THREE_ROUTES_1_FIXES = [
    (r'И это будет вторая часть моего рассказа\.',
     'И это будет [url=2021_three_routes_2.html]вторая часть[/url] моего рассказа.'),
    (r'Москва – Таруса – Москва\. Часть третья\.',
     'Москва – Таруса – Москва. [url=2021_three_routes_3.html]Часть третья[/url].'),
]

THREE_ROUTES_2_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=407874&p=10726076#p10726076\]здесь\[/url\]',
     '[url=2021_three_routes_1.html]здесь[/url]'),
    (r'Но об этом – в отдельной третьей части отчета\.',
     'Но об этом – [url=2021_three_routes_3.html]в отдельной третьей части отчета[/url].'),
]

THREE_ROUTES_3_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=407874&p=10726076#p10726076\]здесь\[/url\]',
     '[url=2021_three_routes_1.html]здесь[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=408209&p=10746504#p10745971\]тут\[/url\]',
     '[url=2021_three_routes_2.html]тут[/url]'),
    (r'Как я уже писал в предисловии к первой части,',
     'Как я уже писал в [url=2021_three_routes_1.html]предисловии к первой части[/url],'),
]

ARMENIA2_FIXES = [
    (r'Я про него в прошлом отчете рассказывал,',
     'Я про него в [url=2023_armenia1.html]прошлом отчете[/url] рассказывал,'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=1466&t=424107&p=11583784#p11583650\] в прошлом году\[/url\]',
     '[url=2023_armenia1.html] в прошлом году[/url]'),
    (r'из уже виденного в прошлом году я с удовольствием',
     'из уже виденного [url=2023_armenia1.html]в прошлом году[/url] я с удовольствием'),
    (r'мы тут были в прошлом году и хорошо все посмотрели',
     'мы тут были [url=2023_armenia1.html]в прошлом году[/url] и хорошо все посмотрели'),
]

BRETAGNE_YEAR_FIXES = [
    (r'Ну а в этот раз, спустя три года, снова соскучившись по Бретани',
     'Ну а в этот раз, [url=2014_east_brittany.html]спустя три года[/url], снова соскучившись по Бретани'),
]

ALPS_FIXES = [
    (r'Как и два года назад, мы хотели проехать исключительно своим ходом',
     'Как и [url=2015_bavaria_salzkammergut.html]два года назад[/url], мы хотели проехать исключительно своим ходом'),
    (r'В первый раз, два года назад, мы там шли сразу после ночных проливных дождей',
     'В первый раз, [url=2015_bavaria_salzkammergut.html]два года назад[/url], мы там шли сразу после ночных проливных дождей'),
]

NORTH_ITALY_FIXES = [
    (r'И, наконец, \[b\]Венеция Серениссима\[/b\]:',
     'И, наконец,\x00SPLIT\x00[b]Венеция Серениссима[/b]'),
]

CROSS_REFERENCE_FIXES = {
    'istanbul_oct': ISTANBUL_OCT_FIXES,
    'venice_dolomites': VENICE_DOLOMITES_FIXES,
    'dolomites_garda': DOLOMITES_GARDA_FIXES,
    'three_routes_1': THREE_ROUTES_1_FIXES,
    'three_routes_2': THREE_ROUTES_2_FIXES,
    'three_routes_3': THREE_ROUTES_3_FIXES,
    'armenia2': ARMENIA2_FIXES,
    'bretagne': BRETAGNE_YEAR_FIXES,
    'alps': ALPS_FIXES,
    'north_italy': NORTH_ITALY_FIXES,
    'normandy': NORMANDY_FIXES,
    'bavaria_salzkammergut': BAVARIA_FIXES,
    'rome': ROME_FIXES,
}
