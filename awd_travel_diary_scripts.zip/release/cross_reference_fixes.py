# -*- coding: utf-8 -*-
"""
Cross-reference fixes: links between the 21 reports themselves, found by
matching forum.awd.ru thread IDs and link labels against the other reports'
titles/topics. Repoints existing forum links to the local sibling file
where confirmed, and adds a local link where the reference was plain text.
"""
import re

ISTANBUL_OCT_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=593&t=406861#p10669090\]Первый\[/url\]',
     '[url=2021_istanbul_nov.html]Первый[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=593&t=406861#p10669090\]'
     r'Стамбул\. Три солнечных ноябрьских дня\.\[/url\]',
     '[url=2021_istanbul_nov.html]Стамбул. Три солнечных ноябрьских дня.[/url]'),
]

VENICE_DOLOMITES_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=616&t=427369\]прошлогоднего Приэльбрусья\[/url\]',
     '[url=2023_elbrus.html]прошлогоднего Приэльбрусья[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=345966&p=8771424#p8771318\]описывая Венецию\[/url\]',
     '[url=2018_north_italy.html#венеция-день-первый]описывая Венецию[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=9804391#p9804391\]в своем отчете про прошлый визит в Доломиты\[/url\]',
     '[url=2019_dolomites_garda.html]в своем отчете про прошлый визит в Доломиты[/url]'),
]

NORMANDY_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=9040394#p9040394\]отчету по Швейцарии\[/url\]',
     '[url=2018_switzerland.html]отчету по Швейцарии[/url]'),
    (r'\[url= https://forum\.awd\.ru/viewtopic\.php\?p=8056574#p8056574\]писал здесь пару лет назад\[/url\]',
     '[url=2017_bretagne.html]писал здесь пару лет назад[/url]'),
    (r'пересаживаемся по Франкфурте,',
     'пересаживаемся во Франкфурте,'),
    (r'Сюда можно попасть с главной страницы \[url\](http://www\.keolis-seine-maritime\.com)\[/url\], кликнув',
     r'Сюда можно попасть [url=\1]с главной страницы[/url], кликнув'),
]

BAVARIA_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=11976712#p11976712\]чуть более полугода назад\[/url\]',
     '[url=2014_salzburg.html]чуть более полугода назад[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=8230996#p8230996\]добро пожаловать\[/url\]',
     '[url=2017_alps.html]добро пожаловать[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=434159#p12041613\]январского Рима\[/url\]',
     '[url=2025_rome.html]январского Рима[/url]'),
]

ROME_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?p=11945794#p11945794\]в августе\[/url\]',
     '[url=2024_venice_dolomites.html]в августе[/url]'),
]

DOLOMITES_GARDA_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=560&t=345966&p=8770478#p8770478\]здесь в моем рассказе\[/url\]',
     '[url=2018_north_italy.html#верона]здесь в моем рассказе[/url]'),
    (r'отправная точка для поиска расписаний в окрестности озера Гарда – сайт '
     r'\[url\](https://www\.arriva\.it/linee-sia)\[/url\], там линий',
     r'отправная точка для поиска расписаний в окрестности озера Гарда – [url=\1]сайт[/url], там линий'),
    (r'вот еще один сайт в помощь при планировании пребывания на Рива-дель-Гарда: '
     r'\[url\](https://www\.gardatrentino\.it/en/lake-garda/)\[/url\]\.',
     r'вот еще один [url=\1]сайт в помощь при планировании[/url] пребывания на Рива-дель-Гарда.'),
    (r'Пользовался сайтом \[url\](https://www\.trentinotrasporti\.it/)\[/url\] в качестве плaнировщика',
     r'Пользовался [url=\1]вот этим сайтом[/url] в качестве плaнировщика'),
    (r'например, сайт \[url= https://moovitapp\.com/index/ru/[^\]]*\] https://moovitapp\.com\[/url\]\.',
     r'например, [url=https://moovitapp.com/index/ru/%D0%9E%D0%B1%D1%89%D0%B5%D1%81%D1%82%D0%B2%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9_%D1%82%D1%80%D0%B0%D0%BD%D1%81%D0%BF%D0%BE%D1%80%D1%82-lines-Trento_e_Belluno-1903-775406]moovit[/url].'),
    (r'Или \[url= https://www\.fassa\.com/EN/How-to-get-here/\] https://www\.fassa\.com/EN/\[/url\] – здесь можно скачать',
     r'Или [url=https://www.fassa.com/EN/How-to-get-here/]сайт Fassa.com[/url] – здесь можно скачать'),
    (r'Основной планировщик по Южному Тиролю, который мы использовали, это '
     r'\[url\](https://www\.sii\.bz\.it/en)\[/url\]\. В частности',
     r'Основной планировщик по Южному Тиролю, который мы использовали, — [url=\1]вот здесь[/url]. В частности'),
    (r'Повторюсь: вся транспортная логистика доступна на \[url\](https://www\.sii\.bz\.it/en)\[/url\]\. Авт',
     r'Повторюсь: вся транспортная логистика доступна [url=\1]здесь[/url]. Авт'),
    (r'Вообще вот основной сайт по Val Gardena: \[url\] (https://www\.valgardena\.it/en/)\[/url\], здесь можно найти',
     r'Вообще вот [url=\1]основной сайт по Val Gardena[/url], здесь можно найти'),
]

THREE_ROUTES_1_FIXES = [
    (r'И это будет вторая часть моего рассказа\.',
     'И это будет [url=2021_three_routes_2.html]вторая часть[/url] моего рассказа.'),
    (r'Москва – Таруса – Москва\. Часть третья\.',
     'Москва – Таруса – Москва. [url=2021_three_routes_3.html]Часть третья[/url].'),
]

THREE_ROUTES_2_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=407874&p=10726076#p10726076\]здесь\[/url\]',
     '[url=2021_three_routes_1.html]здесь[/url]'),
    (r'Но об этом – в отдельной третьей части отчета\.',
     'Но об этом – [url=2021_three_routes_3.html]в отдельной третьей части отчета[/url].'),
]

THREE_ROUTES_3_FIXES = [
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=407874&p=10726076#p10726076\]здесь\[/url\]',
     '[url=2021_three_routes_1.html]здесь[/url]'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=619&t=408209&p=10746504#p10745971\]тут\[/url\]',
     '[url=2021_three_routes_2.html]тут[/url]'),
    (r'Как я уже писал в предисловии к первой части,',
     'Как я уже писал в [url=2021_three_routes_1.html]предисловии к первой части[/url],'),
]

ARMENIA2_FIXES = [
    (r'Я про него в прошлом отчете рассказывал,',
     'Я про него в [url=2023_armenia1.html]прошлом отчете[/url] рассказывал,'),
    (r'\[url=https://forum\.awd\.ru/viewtopic\.php\?f=1466&t=424107&p=11583784#p11583650\] в прошлом году\[/url\]',
     '[url=2023_armenia1.html] в прошлом году[/url]'),
    (r'из уже виденного в прошлом году я с удовольствием',
     'из уже виденного [url=2023_armenia1.html]в прошлом году[/url] я с удовольствием'),
    (r'мы тут были в прошлом году и хорошо все посмотрели',
     'мы тут были [url=2023_armenia1.html]в прошлом году[/url] и хорошо все посмотрели'),
]

BRETAGNE_YEAR_FIXES = [
    (r'Ну а в этот раз, спустя три года, снова соскучившись по Бретани',
     'Ну а в этот раз, [url=2014_east_brittany.html]спустя три года[/url], снова соскучившись по Бретани'),
]

ALPS_FIXES = [
    (r'Как и два года назад, мы хотели проехать исключительно своим ходом',
     'Как и [url=2015_bavaria_salzkammergut.html]два года назад[/url], мы хотели проехать исключительно своим ходом'),
    (r'В первый раз, два года назад, мы там шли сразу после ночных проливных дождей',
     'В первый раз, [url=2015_bavaria_salzkammergut.html]два года назад[/url], мы там шли сразу после ночных проливных дождей'),
    # raw external links hidden under nearby words, per user request
    (r'Расписания и цены корабликов по озеру Wolfgangsee и поездов на вершину Schafberg, '
     r'как по отдельности, так и вместе, можно скачать вот здесь:',
     'Расписания и цены корабликов по озеру Wolfgangsee и поездов на вершину Schafberg, '
     'как по отдельности, так и вместе, можно скачать '
     '[url=http://www.wolfgangseeschifffahrt.at/content/website_schafbergbahn/de_at.html]вот здесь[/url].'),
    (r'\[url\]http://www\.wolfgangseeschifffahrt\.at/content/website_schafbergbahn/de_at\.html\[/url\]',
     '\x00DELETE\x00'),
    (r'вот здесь можно посмотреть круговую панораму с камер на вершине: '
     r'\[url\]https://schafberg\.panomax\.com/\[/url\]\.',
     '[url=https://schafberg.panomax.com/]вот здесь[/url] можно посмотреть круговую панораму с камер на вершине.'),
    (r'Вот здесь можно скачать план остановок на этой площади: '
     r'\[url\]https://salzburg-verkehr\.at/service/downloads/liniennetz-und-umgebungsplaene/\[/url\], '
     r'там, где на странице',
     '[url=https://salzburg-verkehr.at/service/downloads/liniennetz-und-umgebungsplaene/]Вот здесь[/url] '
     'можно скачать план остановок на этой площади, там, где на странице'),
    (r'вот здесь можно посмотреть схему автобусных линий '
     r'\[url\]http://www\.rvo-bus\.de/oberbayernbus/view/mdb/regiobusfranken/oberbayernbus/mdb_183234_liniennetzplan_berchtesgaden\.pdf\[/url\] '
     r'\(ссылка отсюда: \[url\]http://www\.rvo-bus\.de/oberbayernbus/view/fahrplan/liniennetzplan\.shtml\[/url\]\)\.',
     '[url=http://www.rvo-bus.de/oberbayernbus/view/mdb/regiobusfranken/oberbayernbus/mdb_183234_liniennetzplan_berchtesgaden.pdf]здесь[/url] '
     'можно посмотреть схему автобусных линий (Источник этой схемы - '
     '[url=http://www.rvo-bus.de/oberbayernbus/view/fahrplan/liniennetzplan.shtml]здесь[/url]).'),
    (r'начинается с обхода довольно забавного холма Bürglstein:',
     'начинается с обхода довольно забавного холма Bürglstein. Вот '
     '[url=https://www.google.ru/maps/@47.7147407,13.4693419,593a,35y,38.25h,65.96t/data=!3m1!1e3]Google-карта[/url].'),
    (r'^\[url\]https://www\.google\.ru/maps/@47\.7147407,13\.4693419,593a,35y,38\.25h,65\.96t/data=!3m1!1e3\[/url\]$',
     '\x00DELETE\x00'),
]

NORTH_ITALY_FIXES = [
    (r'И, наконец, \[b\]Венеция Серениссима\[/b\]:',
     'И, наконец,\x00SPLIT\x00[b]Венеция Серениссима[/b]'),
    (r'плюс на сайте базилики http://www\.basilicasanzeno\.it можно скачать',
     r'плюс на [url=http://www.basilicasanzeno.it]сайте базилики[/url] можно скачать'),
    (r'\[url=https://www\.travelmagazine\.org/\?tag=basilica-of-saint-anthony-of-padua\]'
     r'на сайте http://www\.travelmagazine\.org\[/url\]',
     r'[url=https://www.travelmagazine.org/?tag=basilica-of-saint-anthony-of-padua]на этом сайте[/url]'),
]

BENELUX_FIXES = [
    (r'Итак, вот этот сайт с макрофотографиями картин Яна ван Эйка: \[url\](http://closertovaneyck\.kikirpa\.be/)\[/url\]\.',
     r'Итак, вот [url=\1]этот сайт с макрофотографиями картин Яна ван Эйка[/url].'),
    (r'- Сайт с 566 771 \(на момент описания\) оцифрованными предметами исторического и художественного наследия Брюгге: '
     r'\[url\](https://erfgoedbrugge\.be/)\[/url\]',
     r'- [url=\1]Сайт с 566 771 (на момент описания) оцифрованными предметами исторического и художественного наследия Брюгге[/url]'),
    (r'Фландрии \[url\](www\.visitflanders\.com)\[/url\] записало',
     r'[url=\1]Фландрии[/url] записало'),
    (r'сделали спецпроект,(.*?)\[url\]https://arzamas\.academy/special/flanders\[/url\]\.',
     r'сделали [url=https://arzamas.academy/special/flanders]спецпроект[/url],\1.'),
    (r'- Полный список музеев города: \[url\](https://visit-bruges\.be/explore/museums/all-museums-town)\[/url\]',
     r'- [url=\1]Полный список музеев города[/url]'),
    (r'Ну и еще раз похвалю шикарный online каталог музея \[url\](https://www\.rijksmuseum\.nl/en/rijksstudio/artists/)\[/url\] – приятно пользоваться',
     r'Ну и еще раз похвалю [url=\1]шикарный online каталог музея[/url] – приятно пользоваться'),
]

ALSACE_FIXES = [
    (r'в http://www\.vialsace\.eu: если',
     r'в [url=http://www.vialsace.eu]vialsace.eu[/url]: если'),
]

ANDALUSIA_FIXES = [
    (r'так что я приведу вот эту ссылку: \[url\](https://tickets\.alhambra-patronato\.es/en/)\[/url\]\)\.',
     r'так что я приведу [url=\1]вот эту ссылку[/url]).'),
    (r'только в определенные моменты \(\[url\](http://www\.palaciodelebrija\.com/Visitas\.html)\[/url\]\)\.',
     r'только в определенные моменты ([url=\1]подробнее здесь[/url]).'),
    (r'рыбка в Bodegas Quitapenas \(http://www\.quitapenas\.es/en/\) – рекомендую\.',
     r'рыбка в [url=http://www.quitapenas.es/en/]Bodegas Quitapenas[/url] – рекомендую.'),
]

SWITZERLAND_FIXES = [
    (r'находится на сайте \[url\](https://www\.pfingstegg\.ch/index\.php/en/timetable-prices-4/wanderkarte)\[/url\], вот она:',
     r'находится на [url=\1]сайте[/url], вот она:'),
    (r'до этого отправление каждые 15 минут: \[url\](https://www\.pfingstegg\.ch/index\.php/fahrplan-preise-3/fahrplan)\[/url\]\),',
     r'до этого отправление каждые 15 минут ([url=\1]подробное расписание[/url]),'),
]

ISTANBUL_NOV_FIXES = [
    (r'на сайте турецкого министерства здравоохранения https://register\.health\.gov\.tr/#\. Форму',
     r'на [url=https://register.health.gov.tr/#]сайте турецкого министерства здравоохранения[/url]. Форму'),
    (r'на сайте Госуслуг https://www\.gosuslugi\.ru/600340/1/form\. Я заполнял',
     r'на [url=https://www.gosuslugi.ru/600340/1/form]сайте Госуслуг[/url]. Я заполнял'),
    (r'на сайте https://kisisellestirme\.istanbulkart\.istanbul/\)\. Страница',
     r'на [url=https://kisisellestirme.istanbulkart.istanbul/]сайте[/url]). Страница'),
]

CROSS_REFERENCE_FIXES = {
    'istanbul_oct': ISTANBUL_OCT_FIXES,
    'venice_dolomites': VENICE_DOLOMITES_FIXES,
    'dolomites_garda': DOLOMITES_GARDA_FIXES,
    'three_routes_1': THREE_ROUTES_1_FIXES,
    'three_routes_2': THREE_ROUTES_2_FIXES,
    'three_routes_3': THREE_ROUTES_3_FIXES,
    'armenia2': ARMENIA2_FIXES,
    'bretagne': BRETAGNE_YEAR_FIXES,
    'alps': ALPS_FIXES,
    'north_italy': NORTH_ITALY_FIXES,
    'normandy': NORMANDY_FIXES,
    'bavaria_salzkammergut': BAVARIA_FIXES,
    'rome': ROME_FIXES,
    'benelux': BENELUX_FIXES,
    'alsace': ALSACE_FIXES,
    'andalusia': ANDALUSIA_FIXES,
    'switzerland': SWITZERLAND_FIXES,
    'istanbul_nov': ISTANBUL_NOV_FIXES,
}
