#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ШАБЛОН для обработки ОДНОГО нового отчёта. Не запускать вслепую —
пройтись по шагам руками/через Claude, подставляя реальные значения.
Подробное описание процесса — в INSTRUCTIONS.md.

Использование (после того как per-file детали ниже заполнены):
    python3 process_new_report_TEMPLATE.py
"""
import subprocess, os, sys

sys.path.insert(0, os.path.dirname(__file__))
from awd_convert import convert
# from cross_reference_fixes import CROSS_REFERENCE_FIXES  # если нужны свои фиксы

os.environ['LANG'] = 'en_US.UTF-8'
os.environ['LC_ALL'] = 'en_US.UTF-8'

# ---- ЗАПОЛНИТЬ ПЕРЕД ЗАПУСКОМ ----
SRC_FILE = '/mnt/user-data/uploads/AWD_-_Название_файла.rtf'  # или .txt
KEY = 'newkey'              # короткий ASCII-идентификатор
YEAR = 2026                 # год самой поездки (не написания!)
TITLE = 'Полное название рассказа, как в оригинале'
OUT_KEY = f'{YEAR}_{KEY}'
STAGE_DIR = '/tmp/stage_new'
# извлечённые вручную/через Claude доп. правки для ЭТОГО файла
# (перекрёстные ссылки на другие рассказы, разовые опечатки и т.п.)
EXTRA_FIXES = [
    # (r'паттерн для re.sub', r'замена'),
]
# -----------------------------------

os.makedirs(STAGE_DIR, exist_ok=True)
is_txt = SRC_FILE.lower().endswith('.txt')

if is_txt:
    processed_src = SRC_FILE
else:
    staged_rtf = os.path.join(STAGE_DIR, KEY + '.rtf')  # ASCII-имя обязательно
    subprocess.run(['cp', SRC_FILE, staged_rtf], check=True)
    subprocess.run(['soffice', '--headless', '--convert-to', 'html', staged_rtf],
                    cwd=STAGE_DIR, check=True, capture_output=True)
    processed_src = os.path.join(STAGE_DIR, KEY + '.html')

out_path = f'/mnt/user-data/outputs/{OUT_KEY}.html'
report = convert(processed_src, TITLE, out_path, extra_fixes=EXTRA_FIXES or None)

print('headers:', len(report['headers']))
for hid, t in report['headers']:
    print('  -', t)
print('subheads:', report['subheads'])
print('leftover_tags (проверь!):', report['leftover_tags'])
print('written to:', report['out_path'])

# Дальше руками:
# 1. Проверить leftover_tags на настоящие проблемы (см. раздел "Известные
#    ложные срабатывания" в INSTRUCTIONS.md).
# 2. Проверить перекрёстные ссылки на forum.awd.ru (см. соответствующий
#    раздел INSTRUCTIONS.md), дополнить EXTRA_FIXES и перезапустить.
# 3. Определить дату поездки, если ещё не известна.
# 4. Добавить запись в REPORTS в build_landing.py и пересобрать index.html.
# 5. Если нашлись новые самоссылки СТАРЫХ файлов НА этот новый файл —
#    добавить фиксы и в cross_reference_fixes.py, пересобрать те файлы тоже.
